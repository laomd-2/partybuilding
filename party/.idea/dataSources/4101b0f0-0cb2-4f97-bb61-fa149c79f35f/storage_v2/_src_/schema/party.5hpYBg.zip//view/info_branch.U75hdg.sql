create definer = root@localhost view info_branch as
select `party`.`info_branch_all`.`id`          AS `id`,
       `party`.`info_branch_all`.`branch_name` AS `branch_name`,
       `party`.`info_branch_all`.`date_create` AS `date_create`,
       `party`.`info_branch_all`.`school_id`   AS `school_id`
from `party`.`info_branch_all`
where ((`party`.`info_branch_all`.`id` = 6) or
       ((`party`.`info_branch_all`.`id` > 72) and (`party`.`info_branch_all`.`id` <> 106)));

