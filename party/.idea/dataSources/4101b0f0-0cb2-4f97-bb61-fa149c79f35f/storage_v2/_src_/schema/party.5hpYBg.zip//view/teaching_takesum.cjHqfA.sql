create definer = root@localhost view teaching_takesum as
select `party`.`teaching_takepartin`.`member_id`   AS `member_id`,
       count(0)                                    AS `activity_count`,
       sum(`party`.`teaching_takepartin`.`credit`) AS `credit_sum`
from `party`.`teaching_takepartin`
group by `party`.`teaching_takepartin`.`member_id`;

