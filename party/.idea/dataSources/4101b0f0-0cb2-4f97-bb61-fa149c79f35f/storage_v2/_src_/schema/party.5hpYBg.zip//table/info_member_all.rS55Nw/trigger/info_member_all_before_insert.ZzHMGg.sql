create definer = root@localhost trigger info_member_all_before_insert
  before INSERT
  on info_member_all
  for each row
BEGIN
  if NEW.second_branch_conference then
      set NEW.phase = 5;
  elseif NEW.first_branch_conference then
      set NEW.phase = 4;
  elseif NEW.key_develop_person_date then
      set NEW.phase = 3;
  elseif NEW.activist_date then
      set NEW.phase = 2;
  elseif NEW.application_date then
      set NEW.phase = 1;
  end if ;
END;

